#!/bin/bash
python runtime/getmodsource.py "$@"
